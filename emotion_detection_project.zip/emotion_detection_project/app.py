from flask import Flask, render_template, Response
import cv2
import numpy as np
from keras.models import model_from_json
import os

# Initialize Flask app
app = Flask(__name__)

# Load the model with absolute paths
json_file_path = os.path.join(os.path.dirname(__file__), 'emotion_model.json')
weights_file_path = os.path.join(os.path.dirname(__file__), 'emotion_model.weights.h5')

# Check if files exist at the specified paths
if not os.path.isfile(json_file_path):
    raise FileNotFoundError(f"Model JSON file not found at {json_file_path}")
if not os.path.isfile(weights_file_path):
    raise FileNotFoundError(f"Model weights file not found at {weights_file_path}")

with open(json_file_path, 'r') as json_file:
    loaded_model_json = json_file.read()

emotion_model = model_from_json(loaded_model_json)
emotion_model.load_weights(weights_file_path)

emotion_dict = {
    0: "Angry",
    1: "Disgusted",
    2: "Fearful",
    3: "Happy",
    4: "Neutral",
    5: "Sad",
    6: "Surprised"
}

# Global variables to manage streaming state
cap = None
is_streaming = False

def detect_emotions():
    global cap, is_streaming

    # Start video capture if not already started
    if cap is None:
        cap = cv2.VideoCapture(0)

    while is_streaming:
        ret, frame = cap.read()

        if not ret:
            break

        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        face_detector = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        num_faces = face_detector.detectMultiScale(gray_frame, scaleFactor=1.3, minNeighbors=5)

        for (x, y, w, h) in num_faces:
            cv2.rectangle(frame, (x, y - 50), (x + w, y + h + 10), (0, 255, 0), 4)
            roi_gray_frame = gray_frame[y:y + h, x:x + w]
            cropped_img = np.expand_dims(np.expand_dims(cv2.resize(roi_gray_frame, (48, 48)), -1), 0)

            try:
                emotion_prediction = emotion_model.predict(cropped_img)
                maxindex = int(np.argmax(emotion_prediction))
                cv2.putText(frame, emotion_dict[maxindex], (x + 5, y - 20), cv2.FONT_HERSHEY_SIMPLEX,
                            1, (0, 0, 255), 2, cv2.LINE_AA)
            except Exception as e:
                print("Error during prediction:", e)

        # Encode the frame into JPEG format to stream over HTTP
        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/video_feed')
def video_feed():
    global is_streaming
    is_streaming = True  # Set the streaming flag to True
    return Response(detect_emotions(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/stop_stream')
def stop_stream():
    global is_streaming, cap
    is_streaming = False  # Stop the streaming
    if cap is not None:
        cap.release()  # Release the camera
        cap = None
    return "Stream stopped"

@app.teardown_appcontext
def shutdown_session(exception=None):
    global cap
    if cap is not None:
        cap.release()
        cap = None

if __name__ == "__main__":
    app.run(debug=True)
